package com.sakshi.springCRUD.dao;


import org.springframework.data.repository.CrudRepository;

import com.sakshi.springCRUD.model.Ticket;

public interface TicketDao extends CrudRepository<Ticket, Integer>{

}
